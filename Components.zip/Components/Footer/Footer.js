import react from "react";
import { ReactDOM } from "react";
import "./footer.css";
class Footer extends react.Component{
    render(){

        return(

            <footer>

                &copy; Worod Ottalah All Rights Reserved 2023

            </footer>

        )

    }

}

export default Footer;